package a_questions;

import java.time.Month;

/**
 * Beispielprogramm für den Workshop "Java 9 Hands On" / das Buch "Java 9 -- Die Neuerungen"
 * 
 * @author Michael Inden
 * 
 * Copyright 2017/2018 by Michael Inden 
 */
public class FallThroughExample {

	public static void main(String[] args) {

		printMonth(Month.JULY);
		printMonth(Month.APRIL);
	}

	private static void printMonth(Month month) {
		String monthString = "";
		switch (month) {
		case JANUARY:
			monthString = "January";
			break;
		default:
			monthString = "N/A"; // hier auch noch Fall Through
		case FEBRUARY:
			monthString = "February";
			break;
		case MARCH:
			monthString = "March";
			break;
		case JULY:
			monthString = "July";
			break;
		}

		System.out.println("OLD: " + month + " = " + monthString); // February
	}
}